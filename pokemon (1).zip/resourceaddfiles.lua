
resource.AddFile("materials/models/props_foliage/arbre01.vmt")
resource.AddFile("materials/models/props_foliage/arbre01.vtf")