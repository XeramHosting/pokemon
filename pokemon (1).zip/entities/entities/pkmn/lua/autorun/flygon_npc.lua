local Category = "Humans + Resistance" 

 
local NPC = {   Name = "Flygon",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/flygon.mdl",
                Health = "200",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "npc_flygon", NPC )
 