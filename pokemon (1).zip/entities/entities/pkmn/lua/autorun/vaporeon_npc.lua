local Category = "Humans + Resistance" 

 
local NPC = {   Name = "Vaporeon",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/vaporeon.mdl",
                Health = "500",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "npc_vaporeon", NPC )
 