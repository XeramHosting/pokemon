local Category = "Humans + Resistance" 

 
local NPC = {   Name = "Glaceon",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/glaceon.mdl",
                Health = "500",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "npc_glaceon", NPC )
 