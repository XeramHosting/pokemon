local Category = "Humans + Resistance" 

 
local NPC = {   Name = "Arcanine",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/arcanine.mdl",
                Health = "500",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "npc_arcanine", NPC )
 