local Category = "NPC" 

 
local NPC = {   Name = "Vaporeon2",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/vaporeon.mdl",
                Health = "500",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "mynpc2", NPC )
 