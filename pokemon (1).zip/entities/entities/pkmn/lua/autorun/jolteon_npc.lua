local Category = "Humans + Resistance" 

 
local NPC = {   Name = "Jolteon",
                Class = "npc_citizen",
                Model = "models/rtbmodels/pokemon/jolteon.mdl",
                Health = "500",
                KeyValues = { citizentype = 4 },
                Category = Category }
 
list.Set( "NPC", "npc_jolteon", NPC )
 